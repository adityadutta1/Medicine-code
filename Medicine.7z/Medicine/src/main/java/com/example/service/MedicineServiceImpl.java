package com.example.service;

import java.util.ArrayList;
import java.util.List;

import com.example.entity.Medicine;
import com.example.exception.MedicineNotFoundException;
import com.example.repository.MedicineRepositoryStub;

public class MedicineServiceImpl implements MedicineService{

	 private MedicineRepositoryStub medicineRepository = new MedicineRepositoryStub();

	    @Override
	    public Medicine getMedicine(int id) throws MedicineNotFoundException {
	        Medicine medicine = medicineRepository.getMedicines().get(id);
	        if (medicine == null) {
	            throw new MedicineNotFoundException();
	        }
	        return medicine;
	    }

	    @Override
	    public Boolean isAvailable(int id) throws MedicineNotFoundException {
	        Medicine medicine = medicineRepository.getMedicines().get(id);
	        if (medicine == null) {
	            throw new MedicineNotFoundException();
	        }
	        return medicine.isAvailability();
	    }

	    @Override
	    public List<String> manufacturers(String name) throws MedicineNotFoundException {
	        List<String> manufacturers = new ArrayList<>();
	        for (Medicine medicine : medicineRepository.getMedicines().values()) {
	            if (medicine.getName().equalsIgnoreCase(name)) {
	                manufacturers.add(medicine.getManufacturer());
	            }
	        }
	        if (manufacturers.isEmpty()) {
	            throw new MedicineNotFoundException();
	        }
	        return manufacturers;
	    }

	    @Override
	    public String getLowestPriceByManufacturer(String medicineName) throws MedicineNotFoundException {
	        double lowestPrice = Double.MAX_VALUE;
	        String lowestPriceManufacturer = null;

	        for (Medicine medicine : medicineRepository.getMedicines().values()) {
	            if (medicine.getName().equalsIgnoreCase(medicineName) && medicine.getPrice() < lowestPrice) {
	                lowestPrice = medicine.getPrice();
	                lowestPriceManufacturer = medicine.getManufacturer();
	            }
	        }

	        if (lowestPriceManufacturer == null) {
	            throw new MedicineNotFoundException();
	        }

	        return lowestPriceManufacturer;
	    }
	    }


