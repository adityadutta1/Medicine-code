package com.example.entity;

import com.example.entity.Medicine;
import com.example.exception.MedicineNotFoundException;
import com.example.service.MedicineService;
import com.example.service.MedicineServiceImpl;
import java.util.List;
 class MedicineServiceTest {

    public static void main(String[] args) {
        testGetMedicine();
        testGetMedicineNotFound();
        testIsAvailable();
        testIsNotAvailable();
        testIsAvailableNotFound();
        testManufacturers();
        testManufacturersNotFound();
        testGetLowestPriceByManufacturer();
        testGetLowestPriceByManufacturerNotFound();
    }

    private static void testGetMedicine() {
        MedicineService medicineService = new MedicineServiceImpl();
        int medicineId = 1;
        try {
            Medicine medicine = medicineService.getMedicine(medicineId);
            System.out.println("Medicine with id " + medicineId + ": " + medicine);
        } catch (MedicineNotFoundException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }

    private static void testGetMedicineNotFound() {
        MedicineService medicineService = new MedicineServiceImpl();
        int nonExistentId = 100;
        try {
            Medicine medicine = medicineService.getMedicine(nonExistentId);
            System.out.println("Medicine with id " + nonExistentId + ": " + medicine);
        } catch (MedicineNotFoundException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }

    private static void testIsAvailable() {
        MedicineService medicineService = new MedicineServiceImpl();
        int availableMedicineId = 2;
        try {
            boolean isAvailable = medicineService.isAvailable(availableMedicineId);
            System.out.println("Medicine with id " + availableMedicineId + " is available: " + isAvailable);
        } catch (MedicineNotFoundException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }

    private static void testIsNotAvailable() {
        MedicineService medicineService = new MedicineServiceImpl();
        int notAvailableMedicineId = 3;
        try {
            boolean isAvailable = medicineService.isAvailable(notAvailableMedicineId);
            System.out.println("Medicine with id " + notAvailableMedicineId + " is available: " + isAvailable);
        } catch (MedicineNotFoundException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }

    private static void testIsAvailableNotFound() {
        MedicineService medicineService = new MedicineServiceImpl();
        int nonExistentId = 100;
        try {
            boolean isAvailable = medicineService.isAvailable(nonExistentId);
            System.out.println("Medicine with id " + nonExistentId + " is available: " + isAvailable);
        } catch (MedicineNotFoundException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }

    private static void testManufacturers() {
        MedicineService medicineService = new MedicineServiceImpl();
        String medicineName = "Aceclofenac";
        try {
            List<String> manufacturers = medicineService.manufacturers(medicineName);
            System.out.println("Manufacturers for medicine " + medicineName + ": " + manufacturers);
        } catch (MedicineNotFoundException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }

    private static void testManufacturersNotFound() {
        MedicineService medicineService = new MedicineServiceImpl();
        String nonExistentName = "NonexistentMedicine";
        try {
            List<String> manufacturers = medicineService.manufacturers(nonExistentName);
            System.out.println("Manufacturers for medicine " + nonExistentName + ": " + manufacturers);
        } catch (MedicineNotFoundException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }

    private static void testGetLowestPriceByManufacturer() {
        MedicineService medicineService = new MedicineServiceImpl();
        String medicineName = "Aceclofenac";
        try {
            String lowestPriceManufacturer = medicineService.getLowestPriceByManufacturer(medicineName);
            System.out.println("Lowest price manufacturer for medicine " + medicineName + ": " + lowestPriceManufacturer);
        } catch (MedicineNotFoundException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }

    private static void testGetLowestPriceByManufacturerNotFound() {
        MedicineService medicineService = new MedicineServiceImpl();
        String nonExistentMedicineName = "NonexistentMedicine";
        try {
            String lowestPriceManufacturer = medicineService.getLowestPriceByManufacturer(nonExistentMedicineName);
            System.out.println("Lowest price manufacturer for medicine " + nonExistentMedicineName + ": " + lowestPriceManufacturer);
        } catch (MedicineNotFoundException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}
